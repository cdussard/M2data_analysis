#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 14:51:16 2022

@author: claire.dussard
"""

mne.make_fixed_length_epochs(raw, duration=1.0, preload=False, reject_by_annotation=True, proj=True, overlap=0.0, verbose=None)


liste_tfr = load_tfr_data(rawPath_main_sujets,"")
#without baseline
av_power_main_withoutBaseline = mne.grand_average(liste_tfr,interpolate_bads=True)

liste_tfr = load_tfr_data(rawPath_pendule_sujets,"")
av_power_pendule_withoutBaseline = mne.grand_average(liste_tfr,interpolate_bads=True)

liste_tfr = load_tfr_data(rawPath_mainIllusion_sujets,"")
av_power_mainIllusion_withoutBaseline = mne.grand_average(liste_tfr,interpolate_bads=True)


for sujet_sansBaseline in liste_tfr:
    #sujet_sansBaseline.plot(picks="C3",fmin=3,fmax=40)
    sujet_sansBaseline.plot_topomap(fmin=8,fmax=30,tmin=1.5,tmax=25.5)
    

av_power_main_withoutBaseline.plot_topomap(fmin=8,fmax=30,tmin=1.5,tmax=25.5)

av_power_main.plot(picks="C3",fmin=3,fmax=40)

raw_signal.plot(block=True)


#affichage des TFR sans Baseline
av_power_pendule_withoutBaseline.plot(picks="C3",fmin=3,fmax=40,vmin=0)
av_power_main_withoutBaseline.plot(picks="C3",fmin=3,fmax=40,vmin=0)
av_power_mainIllusion_withoutBaseline.plot(picks="C3",fmin=3,fmax=40,vmin=0)
raw_signal.plot(block=True)


#cartes de difference


avpower_main_moins_pendule_noBL = av_power_main_withoutBaseline - av_power_pendule_withoutBaseline

avpower_main_moins_mainIllusion_noBL = av_power_main_withoutBaseline - av_power_mainIllusion_withoutBaseline

#avpower_main_moins_pendule_noBL.plot_topomap(fmin=8,fmax=30,tmin=1.5,tmax=25.5)
avpower_main_moins_pendule_noBL.plot(picks="C3",fmin=3,fmax=40)
avpower_main_moins_mainIllusion_noBL.plot(picks="C3",fmin=3,fmax=40)
raw_signal.plot(block=True)



#cartes avec seuil de diff
av_power_main =  mne.time_frequency.read_tfrs("../AV_TFR/all_sujets/main-tfr.h5")[0]
av_power_mainIllusion =  mne.time_frequency.read_tfrs("../AV_TFR/all_sujets/mainIllusion-tfr.h5")[0]
av_power_pendule =  mne.time_frequency.read_tfrs("../AV_TFR/all_sujets/pendule-tfr.h5")[0]

avpower_main_moins_pendule = av_power_main - av_power_pendule
avpower_main_moins_mainIllusion = av_power_main - av_power_mainIllusion

avpower_main_moins_pendule.plot(picks="C3",fmin=3,fmax=40)
avpower_main_moins_mainIllusion.plot(picks="C3",fmin=3,fmax=40)
raw_signal.plot(block=True)
