#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 11:47:54 2022

@author: claire.dussard
"""
#on ne peut pas utiliser les fonctions de frequency power display car elles sont concues avec les données moyennees
#pour l'ANOVA il faut reprendre les donnees des sujets, compute les moving average, averager les points par sujets puis compute l'ANOVA